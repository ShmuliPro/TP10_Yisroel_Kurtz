using System.Data.SqlClient;
using Dapper;
using System.Collections.Generic;
using TP10.Models;

namespace TP10;

public static class BD
{
    private static string _connectionString = @"Server=localhost;DataBase=BDSeries;Trusted_Connection=True;";

     public static List<Series> agarrarLasSeries()
    {
    using (SqlConnection DB = new SqlConnection(_connectionString)){string SQL = "select * from Series";
            return DB.Query<Series>(SQL).ToList();        }
    }
   
    public static Series IdSeries(int IdSerie)
    {using (SqlConnection DB = new SqlConnection(_connectionString)){string SQL = "select * from Series where IdSerie = @pIdSerie";
return DB.QueryFirstOrDefault<Series>(SQL, new{pIdSerie= IdSerie});
        }}
   
   
    public static Actores AgarrarActor(int IdSerie){
        
        
        using (SqlConnection DB = new SqlConnection(_connectionString)){
        
        string SQL = "select * from Actores where IdSerie = @pIdSerie";


            return DB.QueryFirstOrDefault<Actores>(SQL, new{pIdSerie= IdSerie});
        }
    }

     public static Temporadas TemporadasBD(int IdSerie)
    {
        using (SqlConnection DB = new SqlConnection(_connectionString)){
        string SQL = "select * from Temporadas where IdSerie = @pIdSerie";
            return DB.QueryFirstOrDefault<Temporadas>(SQL, new{pIdSerie= IdSerie});
        }
    }
   
}
