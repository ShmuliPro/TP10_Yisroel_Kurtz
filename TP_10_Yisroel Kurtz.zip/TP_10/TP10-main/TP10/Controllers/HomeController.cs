﻿using Microsoft.AspNetCore.Mvc;

namespace TP10.Controllers;

public class HomeController : Controller
{
    public IActionResult Index(){
        ViewBag.Series = BD.agarrarLasSeries();
        return View();}
public Temporadas Temporadasdata(int IdSerie){

    Temporadas Temp = BD.TemporadasBD(IdSerie);
    return Temp;}
   public Actores Actoresdata(int IdSerie){
    Actores Act = BD.AgarrarActor(IdSerie);
    return Act;}
 
  public Series dataSeries(int IdSerie){
    Series Ser = BD.IdSeries(IdSerie);
    return Ser;}
}
