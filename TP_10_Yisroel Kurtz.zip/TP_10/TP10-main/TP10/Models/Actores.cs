using System.Collections.Generic;
using System.Data.SqlClient;

namespace TP10;
public class Actores
{
    public int IdActor {get; set;}
    public int IdSerie{get;set;}
    public string Nombre {get;set;}
    
}