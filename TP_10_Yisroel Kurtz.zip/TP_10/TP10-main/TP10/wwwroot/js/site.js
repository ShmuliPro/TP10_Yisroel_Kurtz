﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

function VerTemporadas(IdS)
{
    $.ajax(     {
            type:'POST',
            dataType:'JSON',
            url:'/Home/Temporadasdata',
            data:{IdSerie:IdS},
            success:
                function(response){
                 $("#Info").html(response.numeroTemporada);
            $("#Info").html(response.tituloTemporada);}


        }

    );
}

function VerActores(IdS)
{
    $.ajax(
            {
                type:'POST',
                dataType:'JSON',
                url:'/Home/Actoresdata',
                data:{IdSerie:IdS},
                success:
                function(response)
                {
                    $("#Info").html(response.nombre);
                }
            }
    );
}

function VerSerie(IdS)
{
    $.ajax(
            {
                type:'POST',
                dataType:'JSON',
                url:'/Home/dataSeries',
                data:{IdSerie:IdS},
                success:
                function(response)
                {
                    $("#Info").html(response.nombre);
                    $("#Info").html(response.añoInicio);
                    $("#Info").html(response.sinopsis);
                    $("#Info").html(response.imagenSerie);
                }
            }
    );
}