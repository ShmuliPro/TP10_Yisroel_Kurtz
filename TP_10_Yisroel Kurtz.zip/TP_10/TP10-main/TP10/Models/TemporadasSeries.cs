using System.Collections.Generic;
using System.Data.SqlClient;

namespace TP10;
public class Temporadas
{
    public int IdTemprorada {get; set;}
    public int IdSerie {get; set;}
    public int NumeroTemporada {get; set;}
    public string TituloTemporada {get;set;}
}